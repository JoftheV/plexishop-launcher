const axios = require('axios');
module.exports = async function notifyTelegram(userId, message) {
  const botToken = process.env.TELEGRAM_TOKEN;
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  await axios.post(url, {
    chat_id: userId,
    text: message,
    parse_mode: 'HTML'
  });
};
