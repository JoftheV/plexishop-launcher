const QRCode = require('qrcode');
module.exports = async function generateQR(link) {
  try {
    return await QRCode.toDataURL(link);
  } catch (err) {
    console.error('QR Code generation failed:', err.message);
    return null;
  }
};
